import asyncio
import os
import shutil
import sqlite3
from telethon import TelegramClient

# Фиксированные API данные
API_ID = 21636249
API_HASH = '05b4ba73bb55976b06a76ec18ed609e4'

async def main():
    try:
        os.mkdir("bad_sessions")
    except FileExistsError:
        pass

    gc = 0  # Счетчик хороших сессий
    to_move = []  # Список сессий для перемещения

    for file in os.listdir():
        if os.path.isfile(file) and file.endswith(".session"):
            filename = os.path.splitext(file)[0]  # Получаем имя без расширения

            try:
                client = TelegramClient(filename, API_ID, API_HASH)
            except sqlite3.DatabaseError:
                print(f"Bad session: {filename}")
                to_move.append(filename)
                continue
            except Exception as err:
                print(f"Bad session: {filename} with error {err.__class__.__name__}")
                to_move.append(filename)
                continue

            try:
                await client.connect()
                if not await client.is_user_authorized():
                    await client.disconnect()
                    print(f"Bad session: {filename} (not authorized)")
                    to_move.append(filename)
                else:
                    gc += 1
                    await client.disconnect()
            except Exception as err:
                await client.disconnect()
                print(f"Bad session: {filename} with error {err.__class__.__name__}")
                to_move.append(filename)
                continue

    # Перемещаем только .session файлы
    for filename in to_move:
        shutil.move(f"{filename}.session", f"bad_sessions/{filename}.session")

    print(f"There are {gc} working sessions")

    input("Press enter to close the window")

if __name__ == '__main__':
    asyncio.run(main())
